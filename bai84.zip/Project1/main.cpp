#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void docMangTuTapTin(string tenTapTin) {
    ifstream file(tenTapTin);
    if (!file.is_open()) {
        cout << "Khong the mo tap tin!" << endl;
        return;
    }

    int n;
    file >> n;
    vector<int> mang(n);

    for (int i = 0; i < n; i++) {
        file >> mang[i];
    }

    cout << "Mang vua doc: ";
    for (int so : mang) {
        cout << so << " ";
    }
    cout << endl;

    file.close();
}

int main() {
    string tenTapTin = "data.txt";
    docMangTuTapTin(tenTapTin);
    return 0;
}

